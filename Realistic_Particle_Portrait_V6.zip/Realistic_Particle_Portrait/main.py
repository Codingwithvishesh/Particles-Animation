#!/usr/bin/env python3
"""
REALISTIC PARTICLE PORTRAIT  -  V6 ULTIMATE EDITION
====================================================

Install:
    pip install pygame numpy pillow rembg onnxruntime imageio imageio-ffmpeg

Run:
    python main.py                      live preview   (SPACE restart, P pause, ESC quit)
    python main.py --export             render a Reels-ready MP4 into output/  (1080x1920)
    python main.py --image input/thor.png --name "THOR" --export

Options:
    --scale N    render scale (export default 2 = 1080x1920, live default 1 = 540x960)
    --fps N      export frame rate (default 30)
    --seed N     same seed = identical animation every time
    --no-cache   redo the AI background removal
"""

from __future__ import annotations

import argparse
import hashlib
import math
import sys
import time
from pathlib import Path

import numpy as np
import pygame
from PIL import Image, ImageEnhance, ImageFilter, ImageOps

# =====================================================
# SETTINGS  (edit these freely)
# =====================================================

CHARACTER_NAME = "IRON MAN"
SUBTITLE_TEXT = "CINEMATIC PARTICLE PORTRAIT"
FOOTER_TEXT = "CREATED WITH PYTHON"
WINDOW_TITLE = "Cinematic Particle Portrait V6"

# Folders are relative to this file, so it works from any terminal location
BASE_DIR = Path(__file__).resolve().parent
INPUT_FOLDER = BASE_DIR / "input"
OUTPUT_FOLDER = BASE_DIR / "output"
CACHE_FOLDER = BASE_DIR / ".cache"

# Design resolution (scale 1). Export multiplies everything by --scale.
BASE_WIDTH = 540
BASE_HEIGHT = 960
FPS = 60            # live preview
EXPORT_FPS = 30     # video export
EXPORT_CRF = 23     # video quality: lower = sharper but bigger file (18 = near-lossless, 26 = small)

# Particles
MAX_PARTICLES = 90000       # at scale 1 (auto x scale^2)
PARTICLE_STEP = 2           # sampling grid in output pixels
PARTICLE_SIZE = 2           # particle block size in output pixels

# Timeline (seconds) - total stays exactly 20 s
INTRO_TIME = 2.0
GATHER_TIME = 9.0
HOLD_TIME = 7.0
DISPERSE_TIME = 2.0
TOTAL_DURATION = INTRO_TIME + GATHER_TIME + HOLD_TIME + DISPERSE_TIME

# Portrait placement (scale 1 pixels)
IMAGE_MAX_WIDTH = 500
IMAGE_MAX_HEIGHT = 735
IMAGE_TOP = 35
TITLE_Y, SUBTITLE_Y, REPLAY_Y, FOOTER_Y = 825, 875, 900, 930

# Background removal
REMBG_MODEL = "u2net"       # light + fast. Alternatives: "isnet-general-use", "birefnet-general"
ALPHA_THRESHOLD = 90        # higher = cleaner edges, lower = more detail
ERODE_EDGE = True           # removes the 1px halo the AI leaves around the character

# Colour grade. V5 used brightness 1.12 / gamma 0.85 / gain 1.10 / lift 0.025, but its portrait
# had ~30% accidental black holes, so it looked darker. The portrait is solid now -> slightly lower.
GRADE_BRIGHTNESS = 1.00
GRADE_GAMMA = 0.92
GRADE_GAIN = 1.04
GRADE_LIFT = 0.0

# Motion
DRIFT_SPEED = 12.0          # idle drift in the intro (px/s at scale 1)
START_DIM = 0.50            # particles start dim and brighten as they settle
FADE_IN_TIME = 1.0
DELAY_MAX = 0.60            # how staggered the arrival is (0 = all together)
SWIRL = 0.22                # arc of the flight paths (0 = straight lines)
TWINKLE = 0.14             # per-particle shimmer in the hold phase (0 = off)
BURST_DISTANCE = 420.0      # explosion reach (px at scale 1)

# Look
BG_EDGE = (2, 3, 10)
BG_CENTER = (8, 14, 34)
TITLE_COLOR = (110, 205, 255)
BLOOM_THRESHOLD = 150       # only areas brighter than this glow (keeps dark armor rich)
BLOOM_GAIN = 1.5
BLOOM_NEAR = 0.60           # tight glow strength (0 = off)
BLOOM_FAR = 0.85            # wide glow strength  (0 = off)
SCAN_LIGHT = True           # cyan light sweep across the portrait in the hold phase
SCAN_SWEEPS = 2
SCAN_GAIN = 0.35
SCAN_TINT = (14.0, 34.0, 48.0)

_LUMA = np.array([0.299, 0.587, 0.114], dtype=np.float32)

SUPPORTED = {".jpg", ".jpeg", ".png", ".webp"}

HOLD_START = INTRO_TIME + GATHER_TIME
HOLD_END = HOLD_START + HOLD_TIME


# =====================================================
# SMALL HELPERS
# =====================================================

def smoothstep(x):
    return x * x * (3.0 - 2.0 * x)


def smootherstep(x):
    return x * x * x * (x * (x * 6.0 - 15.0) + 10.0)


class Layout:
    """All pixel sizes derived from one scale factor."""

    def __init__(self, scale: int):
        s = self.scale = scale
        self.width = BASE_WIDTH * s
        self.height = BASE_HEIGHT * s
        self.img_w = IMAGE_MAX_WIDTH * s
        self.img_h = IMAGE_MAX_HEIGHT * s
        self.img_top = IMAGE_TOP * s
        self.title_y = TITLE_Y * s
        self.subtitle_y = SUBTITLE_Y * s
        self.replay_y = REPLAY_Y * s
        self.footer_y = FOOTER_Y * s
        self.max_particles = MAX_PARTICLES * s * s


# =====================================================
# IMAGE LOADING + BACKGROUND REMOVAL (cached)
# =====================================================

def find_image(explicit: str | None) -> Path:
    if explicit:
        path = Path(explicit)
        if not path.is_file():
            path = BASE_DIR / explicit
        if not path.is_file():
            sys.exit(f"Image not found: {explicit}")
        return path

    INPUT_FOLDER.mkdir(exist_ok=True)
    images = [p for p in INPUT_FOLDER.iterdir() if p.suffix.lower() in SUPPORTED]
    if not images:
        sys.exit("No image found inside the 'input' folder!")

    images.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    if len(images) > 1:
        print(f"Multiple images found - using the newest: {images[0].name}")
    return images[0]


def cut_out_character(path: Path, use_cache: bool) -> Image.Image:
    """Returns an RGBA image with the background removed (AI result is cached on disk)."""
    original = ImageOps.exif_transpose(Image.open(path)).convert("RGBA")

    # Already a transparent PNG? No AI needed.
    if original.getchannel("A").getextrema()[0] < 250:
        print("Transparent image detected - skipping background removal.")
        return original

    key = hashlib.sha1(path.read_bytes() + REMBG_MODEL.encode()).hexdigest()[:16]
    cache_file = CACHE_FOLDER / f"{path.stem}_{key}.png"

    if use_cache and cache_file.exists():
        print("Using cached background removal.")
        return Image.open(cache_file).convert("RGBA")

    try:
        from rembg import new_session, remove
    except ImportError:
        sys.exit("rembg is not installed.  Run:  pip install rembg onnxruntime")

    print(f"Removing background with AI ({REMBG_MODEL}) ...")
    result = remove(original, session=new_session(REMBG_MODEL)).convert("RGBA")

    CACHE_FOLDER.mkdir(exist_ok=True)
    result.save(cache_file)
    return result


def grade_colors(rgb: Image.Image) -> np.ndarray:
    """V5's cinematic grade (re-balanced, see settings) + a light sharpen so details survive the upscale."""
    rgb = rgb.filter(ImageFilter.UnsharpMask(radius=1.2, percent=70, threshold=2))
    rgb = ImageEnhance.Contrast(rgb).enhance(1.18)
    rgb = ImageEnhance.Color(rgb).enhance(1.12)
    rgb = ImageEnhance.Brightness(rgb).enhance(GRADE_BRIGHTNESS)

    norm = np.asarray(rgb, dtype=np.float32) / 255.0
    norm = np.power(norm, GRADE_GAMMA)                # lift dark armor
    norm = np.clip(norm * GRADE_GAIN + GRADE_LIFT, 0.0, 1.0)
    return (norm * 255.0).astype(np.uint8)


def build_targets(cutout: Image.Image, layout: Layout, rng: np.random.Generator):
    bbox = cutout.getchannel("A").getbbox()
    if bbox is None:
        sys.exit("Character not detected in image.")

    character = ImageOps.contain(
        cutout.crop(bbox),
        (layout.img_w, layout.img_h),
        method=Image.Resampling.LANCZOS,
    )

    alpha_img = character.getchannel("A")
    if ERODE_EDGE:
        alpha_img = alpha_img.filter(ImageFilter.MinFilter(3))

    alpha = np.asarray(alpha_img)
    rgb = grade_colors(character.convert("RGB"))

    h, w = alpha.shape
    offset_x = (layout.width - w) // 2
    offset_y = layout.img_top + (layout.img_h - h) // 2

    step = PARTICLE_STEP
    ys, xs = np.nonzero(alpha[::step, ::step] > ALPHA_THRESHOLD)
    if len(xs) == 0:
        sys.exit("No particles generated from image.")

    colors = rgb[::step, ::step][ys, xs]
    targets = np.column_stack((xs * step + offset_x, ys * step + offset_y)).astype(np.float32)

    if len(targets) > layout.max_particles:
        keep = rng.choice(len(targets), layout.max_particles, replace=False)
        targets, colors = targets[keep], colors[keep]

    print(f"Total particles: {len(targets):,}")
    return targets, colors


# =====================================================
# PARTICLE SYSTEM
#   state(t) is a pure function of time -> live preview and
#   video export are frame-perfect identical, no drift, no lag desync.
# =====================================================

class ParticleSystem:
    def __init__(self, targets, colors, layout: Layout, rng: np.random.Generator):
        s = layout.scale
        n = self.n = len(targets)
        self.targets = targets
        self.base = colors.astype(np.float32)
        self.s = s

        # idle cloud
        self.start = np.column_stack((
            rng.uniform(0, layout.width, n),
            rng.uniform(0, layout.height, n),
        )).astype(np.float32)
        angle = rng.uniform(0, math.tau, n)
        speed = rng.uniform(0.4, 1.0, n) * DRIFT_SPEED * s
        self.drift = (np.column_stack((np.cos(angle), np.sin(angle))) * speed[:, None]).astype(np.float32)

        # arrival order: random + slightly top-to-bottom reveal
        self.ty = targets[:, 1]
        self.y0 = float(self.ty.min())
        self.h = max(1.0, float(self.ty.max()) - self.y0)
        ynorm = (self.ty - self.y0) / self.h
        self.delay = (DELAY_MAX * (0.65 * rng.random(n) + 0.35 * ynorm)).astype(np.float32)

        # curved flight path (perpendicular offset, bigger arcs for longer trips)
        d = targets - self.start
        dist = np.maximum(np.hypot(d[:, 0], d[:, 1]), 1e-3)
        perp = np.column_stack((-d[:, 1], d[:, 0])) / dist[:, None]
        arc = rng.uniform(-1, 1, n) * SWIRL * dist
        self.perp = (perp * arc[:, None]).astype(np.float32)

        # explosion vectors (slight upward bias, individual speeds)
        ang2 = rng.uniform(0, math.tau, n)
        reach = rng.uniform(0.35, 1.0, n) * BURST_DISTANCE * s
        burst = np.column_stack((np.cos(ang2), np.sin(ang2) - 0.25)) * reach[:, None]
        self.burst = burst.astype(np.float32)

        # shimmer phases (brightness twinkle keeps the portrait crisp - moving whole pixels
        # would punch random holes into the 2x2 particle grid)
        self.twinkle = rng.uniform(0, math.tau, n).astype(np.float32)

    def _twinkle(self, t, ramp=1.0):
        return 1.0 + (TWINKLE * ramp) * np.sin(t * 3.0 + self.twinkle)

    def _scan(self, th):
        """Cyan light band moving down the portrait. Returns per-particle 0..1 or None."""
        if not SCAN_LIGHT:
            return None
        frac = (th / HOLD_TIME * SCAN_SWEEPS) % 1.0
        center = self.y0 - 0.25 * self.h + frac * 1.5 * self.h
        sigma = 0.07 * self.h
        return np.exp(-(((self.ty - center) / sigma) ** 2)).astype(np.float32)

    def state(self, t: float):
        """Returns (positions[n,2], light[n] or scalar, glow[n] or None)."""
        t = min(max(t, 0.0), TOTAL_DURATION)
        drifted = self.start + self.drift * t

        # PHASE 1 - INTRO: dim cloud fades in and drifts
        if t < INTRO_TIME:
            return drifted, START_DIM * smoothstep(min(t / FADE_IN_TIME, 1.0)), None

        # PHASE 2 - FORMATION: staggered, curved flight to the portrait
        if t < HOLD_START:
            progress = (t - INTRO_TIME) / GATHER_TIME
            local = np.clip((progress - self.delay) / (1.0 - DELAY_MAX), 0.0, 1.0)
            e = smootherstep(local).astype(np.float32)
            pos = drifted + (self.targets - drifted) * e[:, None]
            pos += self.perp * np.sin(np.pi * e)[:, None]
            return pos, START_DIM + (1.0 - START_DIM) * e, None

        # PHASE 3 - HOLD: twinkle + light sweep
        if t < HOLD_END:
            th = t - HOLD_START
            ramp = smoothstep(min(th, 1.0))
            return self.targets, self._twinkle(t, ramp), self._scan(th)

        # PHASE 4 - DISPERSE: accelerating burst + fade out
        s = (t - HOLD_END) / DISPERSE_TIME
        pos = self.targets + self.burst * (s ** 1.7)
        return pos, (1.0 - s) ** 1.5 * self._twinkle(t), None


# =====================================================
# RENDERER
# =====================================================

class Renderer:
    def __init__(self, system: ParticleSystem, layout: Layout, title: str):
        self.system = system
        self.L = layout
        w, h = layout.width, layout.height

        self.canvas = pygame.Surface((w, h), 0, 32)
        self.background = self._make_background()

        # bloom buffers (allocated once)
        self.near = pygame.Surface((max(1, w // 3), max(1, h // 3)), 0, 32)
        self.far = pygame.Surface((max(1, w // 8), max(1, h // 8)), 0, 32)
        self.big = pygame.Surface((w, h), 0, 32)

        self.scan_tint = np.asarray(SCAN_TINT, dtype=np.float32)

        # text is rendered ONCE (V5 re-rendered it every frame)
        s = layout.scale
        font_names = "arial,helvetica,dejavusans,sans"
        title_font = pygame.font.SysFont(font_names, 48 * s, bold=True)
        sub_font = pygame.font.SysFont(font_names, 17 * s, bold=True)
        foot_font = pygame.font.SysFont(font_names, 13 * s)

        self.title = title_font.render(title, True, TITLE_COLOR)
        self.title_glow = title_font.render(title, True, (0, 90, 220))
        self.title_rect = self.title.get_rect(center=(w // 2, layout.title_y))
        self.subtitle = sub_font.render(SUBTITLE_TEXT, True, (125, 155, 195))
        self.replay = sub_font.render("PRESS SPACE TO REPLAY", True, (110, 190, 255))
        self.footer = foot_font.render(FOOTER_TEXT, True, (65, 80, 110))

    def _make_background(self):
        """Soft radial backdrop with dithering (prevents banding in dark gradients)."""
        w, h = self.L.width, self.L.height
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        r = np.sqrt(((xx - w / 2) / (w * 0.75)) ** 2 + ((yy - h * 0.45) / (h * 0.60)) ** 2)
        k = (np.clip(1.0 - r, 0.0, 1.0) ** 2)[..., None]
        edge = np.asarray(BG_EDGE, np.float32)
        center = np.asarray(BG_CENTER, np.float32)
        img = edge + (center - edge) * k
        img += np.random.default_rng(0).random(img.shape, dtype=np.float32)
        arr = np.clip(np.floor(img), 0, 255).astype(np.uint8).transpose(1, 0, 2)
        surf = pygame.Surface((w, h), 0, 32)
        pygame.surfarray.blit_array(surf, arr)
        return surf

    # ---------- drawing ----------

    def draw(self, t: float, replay_hint: bool = False) -> pygame.Surface:
        self.canvas.blit(self.background, (0, 0))
        pos, light, glow = self.system.state(t)
        self._draw_particles(pos, light, glow)
        self._bloom()
        self._draw_text(t, replay_hint)
        return self.canvas

    def _draw_particles(self, pos, light, glow):
        n = self.system.n
        w, h = self.L.width, self.L.height
        size = PARTICLE_SIZE

        light = np.broadcast_to(np.asarray(light, dtype=np.float32), (n,))

        rgb = self.system.base * light[:, None]
        if glow is not None:
            rgb *= (1.0 + SCAN_GAIN * glow)[:, None]
            rgb += glow[:, None] * self.scan_tint
        colors = np.clip(rgb, 0, 255).astype(np.uint8)

        px = np.rint(pos[:, 0]).astype(np.int32)
        py = np.rint(pos[:, 1]).astype(np.int32)
        ok = (px >= 0) & (py >= 0) & (px <= w - size) & (py <= h - size) & (light > 0.004)
        if not ok.any():
            return

        px, py, colors = px[ok], py[ok], colors[ok]

        pixels = pygame.surfarray.pixels3d(self.canvas)
        try:
            for dx in range(size):
                for dy in range(size):
                    pixels[px + dx, py + dy] = colors
        finally:
            del pixels  # always unlock the surface

    def _bloom(self):
        """Bright-pass bloom: only the bright parts glow (arc reactor, eyes, highlights),
        dark armor keeps its colour. Replaces V5's slow Python glow loop."""
        if BLOOM_NEAR <= 0 and BLOOM_FAR <= 0:
            return
        size = self.canvas.get_size()
        pygame.transform.smoothscale(self.canvas, self.near.get_size(), self.near)

        # luminance bright-pass on the SMALL buffer (cheap): only near-white hot spots glow,
        # keeping their own colour. Red/dark armor never gets a haze.
        pixels = pygame.surfarray.pixels3d(self.near)
        try:
            px = pixels.astype(np.float32)
            lum = px @ _LUMA
            mask = np.clip((lum - BLOOM_THRESHOLD) * BLOOM_GAIN / (255.0 - BLOOM_THRESHOLD), 0.0, 1.0)
            pixels[...] = (px * mask[..., None]).astype(np.uint8)
        finally:
            del pixels

        pygame.transform.smoothscale(self.near, self.far.get_size(), self.far)

        # strength is applied on the small buffers too (9-64x fewer pixels = much faster)
        for source, strength in ((self.near, BLOOM_NEAR), (self.far, BLOOM_FAR)):
            k = int(255 * min(strength, 1.0))
            source.fill((k, k, k), special_flags=pygame.BLEND_RGB_MULT)

        for source, strength in ((self.near, BLOOM_NEAR), (self.far, BLOOM_FAR)):
            if strength <= 0:
                continue
            pygame.transform.smoothscale(source, size, self.big)
            self.canvas.blit(self.big, (0, 0), special_flags=pygame.BLEND_RGB_ADD)

    def _draw_text(self, t: float, replay_hint: bool):
        L, c = self.L, self.canvas
        s = L.scale

        if t > HOLD_START:
            fade = min(1.0, (t - HOLD_START) / 1.5)
            pulse = 0.92 + 0.08 * math.sin(t * 2.5)
            alpha = int(255 * fade * pulse)

            self.title.set_alpha(alpha)
            self.title_glow.set_alpha(int(alpha * 0.55))
            c.blit(self.title_glow, (self.title_rect.x + 2 * s, self.title_rect.y + 3 * s))
            c.blit(self.title, self.title_rect)
            c.blit(self.subtitle, self.subtitle.get_rect(center=(L.width // 2, L.subtitle_y)))

        c.blit(self.footer, self.footer.get_rect(center=(L.width // 2, L.footer_y)))

        if replay_hint:
            c.blit(self.replay, self.replay.get_rect(center=(L.width // 2, L.replay_y)))


# =====================================================
# LIVE PREVIEW
# =====================================================

def run_live(renderer: Renderer, layout: Layout):
    pygame.display.init()
    screen = pygame.display.set_mode((layout.width, layout.height))
    pygame.display.set_caption(WINDOW_TITLE)
    clock = pygame.time.Clock()

    print("\nAnimation ready!  Duration:", TOTAL_DURATION, "s")
    print("SPACE / R = restart   P = pause   ESC = exit")

    t = 0.0
    paused = False
    running = True
    last_caption = 0.0

    while running:
        dt = min(clock.tick(FPS) / 1000.0, 0.1)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key in (pygame.K_SPACE, pygame.K_r):
                    t, paused = 0.0, False
                elif event.key == pygame.K_p:
                    paused = not paused

        if not paused:
            t = min(t + dt, TOTAL_DURATION)

        screen.blit(renderer.draw(t, replay_hint=t >= TOTAL_DURATION), (0, 0))
        pygame.display.flip()

        now = time.time()
        if now - last_caption > 0.5:
            last_caption = now
            state = "PAUSED" if paused else f"{t:4.1f}s"
            pygame.display.set_caption(f"{WINDOW_TITLE}  |  {clock.get_fps():.0f} FPS  |  {state}")

    pygame.quit()


# =====================================================
# VIDEO EXPORT  (frame-perfect, no screen recorder needed)
# =====================================================

def run_export(renderer: Renderer, layout: Layout, fps: int, out_path: Path):
    try:
        import imageio.v2 as imageio
    except ImportError:
        sys.exit("Export needs imageio.  Run:  pip install imageio imageio-ffmpeg")

    frames = round(TOTAL_DURATION * fps)
    print(f"\nExporting {frames} frames  {layout.width}x{layout.height} @ {fps} FPS ...")

    # Cover image for the Reel (portrait fully formed, title visible)
    cover = OUTPUT_FOLDER / f"{out_path.stem}_cover.png"
    pygame.image.save(renderer.draw(HOLD_START + 2.5), str(cover))

    try:
        writer = imageio.get_writer(
            str(out_path), fps=fps, codec="libx264", quality=None,
            pixelformat="yuv420p", macro_block_size=1,
            ffmpeg_params=["-crf", str(EXPORT_CRF), "-preset", "medium", "-movflags", "+faststart"],
        )
    except Exception as error:  # missing ffmpeg plugin
        sys.exit(f"Could not start the video writer ({error}).  Run:  pip install imageio-ffmpeg")

    started = time.time()
    try:
        for i in range(frames):
            surface = renderer.draw(i / fps)
            frame = np.ascontiguousarray(pygame.surfarray.array3d(surface).swapaxes(0, 1))
            writer.append_data(frame)

            if i % 15 == 0 or i == frames - 1:
                done = (i + 1) / frames
                eta = (time.time() - started) / done * (1 - done)
                print(f"\r  {done * 100:5.1f}%   ETA {eta:4.0f}s ", end="", flush=True)
    finally:
        writer.close()

    print(f"\n\nDONE ->  {out_path}\n         {cover}")


# =====================================================
# MAIN
# =====================================================

def parse_args():
    p = argparse.ArgumentParser(description="Realistic Particle Portrait V6")
    p.add_argument("--export", action="store_true", help="render an MP4 into output/ instead of opening a window")
    p.add_argument("--image", help="image path (default: newest image inside input/)")
    p.add_argument("--name", help="title text shown under the portrait")
    p.add_argument("--scale", type=int, choices=[1, 2, 3], help="render scale (export default 2, live default 1)")
    p.add_argument("--fps", type=int, help=f"export FPS (default {EXPORT_FPS})")
    p.add_argument("--seed", type=int, help="fixed random seed for a repeatable animation")
    p.add_argument("--no-cache", action="store_true", help="ignore cached background removal")
    return p.parse_args()


def main():
    args = parse_args()

    print("\n====================================")
    print(" REALISTIC PARTICLE PORTRAIT V6")
    print("====================================")

    pygame.font.init()
    OUTPUT_FOLDER.mkdir(exist_ok=True)

    scale = args.scale or (2 if args.export else 1)
    layout = Layout(scale)

    image_path = find_image(args.image)
    print("Character image:", image_path.name)

    cutout = cut_out_character(image_path, use_cache=not args.no_cache)
    rng = np.random.default_rng(args.seed)
    targets, colors = build_targets(cutout, layout, rng)

    system = ParticleSystem(targets, colors, layout, rng)
    renderer = Renderer(system, layout, args.name or CHARACTER_NAME)

    if args.export:
        out_path = OUTPUT_FOLDER / f"{image_path.stem}_particle_portrait.mp4"
        run_export(renderer, layout, args.fps or EXPORT_FPS, out_path)
    else:
        run_live(renderer, layout)


if __name__ == "__main__":
    main()
