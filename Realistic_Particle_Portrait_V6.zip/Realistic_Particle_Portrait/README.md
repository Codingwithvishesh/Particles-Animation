# Realistic Particle Portrait — V6 Ultimate

## Install (ek baar)
```
pip install pygame numpy pillow rembg onnxruntime imageio imageio-ffmpeg
```

## Run
| Command | Kya hota hai |
|---|---|
| `python main.py` | Live preview (540x960, 60 FPS) |
| `python main.py --export` | **MP4 export** → `output/` me (1080x1920, 20 sec, Reels ready) + cover PNG |
| `python main.py --image input/thor.png --name "THOR" --export` | Koi bhi image / naam |
| `python main.py --export --seed 7` | Same seed = hamesha same animation |
| `python main.py --export --scale 1` | Chhota/fast export (540x960) |

Keys (live): `SPACE` restart · `P` pause · `ESC` quit

## Tips
- **Input image jitni high-res, output utna sharp.** 1000px+ wali image use karo, 500px se upar ka farak saaf dikhta hai.
- Pehli baar background removal me model download hota hai. Result `.cache/` me save hota hai, agli baar instant.
- Video file badi aaye to `EXPORT_CRF` badhao (23 → 26). Instagram waise bhi recompress karta hai.
- Saari settings `main.py` ke upar hain: timing, glow, scan light, colors, particle size.
- Particle-dots wala look chahiye? `PARTICLE_STEP = 3` rakho (size 2 ke saath dots ke beech gap aayega).
